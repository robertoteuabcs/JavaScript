function Persona(attrs){
	this.first_name = attrs.first_name || '';
	this.last_name = attrs.last_name || '';
	this.age = attrs.age || 0;
}