$(document).ready(function(){
	
	var intervalID = window.setInterval(function(){
		if($("#my-select option").length == 0){
			var mf = facebookGraph.getInstance();
			mf.getAlbumsByProfile('uabcsdsc');
			mf.createSelectByExistedYears();
		}else{
			window.clearInterval(intervalID);
		}
	}, 1);
	

	$("#year_2012").click(function(event){
		if(this.checked){
			mf.getAlbumsByYear(this.value);
		}else{
			mf.removeAlbumByYear(this.value);
		}
		mf.displayPhotos();
		console.log(mf);
	});

	$("#year_2013").click(function(event){
		if(this.checked){
			mf.getAlbumsByYear(this.value);
		}else{
			mf.removeAlbumByYear(this.value);
		}
		mf.displayPhotos();
		console.log(mf);
	});

});