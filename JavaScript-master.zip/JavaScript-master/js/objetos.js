//Objetos
var myObjeto = new Object();
//declaración de propiedades
myObjeto.propiedad1 = "Valor 1 de la propiedad";
myObjeto.propiedad2 = "Valor 2 de la propiedad";
myObjeto.propiedadNumerica = 12345;
myObjeto.propiedadBooleana = true;
//Declaración de Funciones o Metodos en objetos
myObjeto.miFuncion = function(){
	alert("Hola desde Mi Funcion con Objetos");
}

//Objetos con notacion literal
var myObjeto2 = {
	propiedad1 : "valor",
	propiedad2 : "valor",
	propiedadNumerica: 12345,
	propiedadBooleana: true,
	miFuncion: function(){
		alert("Hola desde mi funcion");
	}
}
