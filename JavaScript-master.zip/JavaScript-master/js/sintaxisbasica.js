/*La sintaxis en JavaScript es sensible a minusculas y mayusculas
en variables, nombres de funciones y operadores no es lo mismo 
la variable test a la variable Test*/

/*Identificadores
es el nombre de una variable, funcion, propiedad o parametro(Argumento de Funcion)
los identificadores pueden tener uno o más caracteres en el siguiente formato:
 -el primer caracter debe ser una letra, un guión bajo (_) o un signo de moneda ($)
 -todos los demas caracteres pueden ser una letras, guión bajo, signo de moneda o numeros
*/

/* No es recomendable usar letras con caracteres especiales*/

/* Por convención de identificadores de ECMAScript usar camel case
 esto significa que la primera letra debe ser en minuscula y cada palabra adicional
 comienza con mayuscula
 */
// miArreglo , miFuncion , miVariable , miObjeto, miPropiedad

// Comentarios
//Comentarios de una sola linea se utiliza //

//Comentarios multilinea se utiliza
/*
 * aqui va el comentario multilinea
 * 
 * */

//Declaraciones en una linea

var suma = numero1 + numero2;

/*Declaraciones multilinea pueden ser combinadas utilizando el estilo de sintaxis de C,
comenzando con la llave de apertura ({) y terminando con la de cierre (})*/

if(suma > 10){
	alert("El numero es mayor de 10");
}

//Variables
miVariableGlobal ="Variable Global";

var miVariableLocal ="Variable Local";

var miVariableCadena ="Valor";
var miVariableNumerica = 12345;
var miVariableBoolean =  true;
var miVariableIndefinida; //se crea con valor undefined




