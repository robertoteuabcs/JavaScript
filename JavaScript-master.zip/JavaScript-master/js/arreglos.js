//Creación de Arreglos en dos formas básicas
//Primera Forma instanciando desde el Objeto Array
var arreglo = new Array();
//si sabes la cantidad de elementos que van existir ejemplo 20
var arreglo = new Array(20);
//si deseas introducir elementos, el constructor de Array
//recibe parametros
var arreglo = new Array("elemento1", "elemento2", "elemento3");
//es posible omitir el operador new
var arreglo = Array(); var arreglo = Array(20);
var arreglo = Array("elemento1", "elemento2", "elemento3");

//Segunda Forma es utilizando notación literal
var arreglo = [];
//Introduciendo elementos
var arreglo = ["elemento1", "elemento2", "elemento3"];
//Dependiendo el navegador por la versión pueden ser 2 o 3 elementos
//declarando los espacios
var arreglo = [1,2,]; var arreglo = [,,];
//asignar valor en arreglo donde 0 es la posición del indice del arreglo
arreglo[0]="valor";
//obtener valor del arreglo donde 0 es la posición del indice del arreglo
alert(arreglo[0]);

