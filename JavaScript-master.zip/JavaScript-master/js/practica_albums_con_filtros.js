//Ocupamos Cargar JQuery
$(document).ready(function(){
//Creacion de variables principales
window.albums = [];
window.photos = [];
window.indice = 0;
window.album_seleccionado_nombre = {};
window.albums_seleccionado_year = [];
$.getJSON('http://graph.facebook.com/uabcsdsc/albums',function(response){
	response.data.forEach(function(item, index, array){
		albums.push(item);
		//console.log(albums);	
	});
});
var elemento = document.getElementById("album-nombre");
console.log(elemento);
elemento.onkeyup = function(event){
	//console.log(window.albums[0].name);
	//console.log($("#album-nombre").val());
	window.albums.forEach(function(item, index, array){
		//console.log($("#album-nombre").val());
		//console.log(item.name);
		if($("#album-nombre").val()==item.name){
			window.album_seleccionado_nombre = item;
		}
	});
	if(window.album_seleccionado_nombre.id != null){
		$.getJSON('http://graph.facebook.com/'+window.album_seleccionado_nombre.id+'/photos',
			function(response){
				var imagenes = "";
				response.data.forEach(function(item, index, array){
					imagenes += "<div class='miimg'><img src='"+item.picture+"'/></div>";
				});
				$("#contenedor-info-personal").html(imagenes);
			});
	}
};
var check2011 = document.getElementById("album_year_2012");
check2011.onclick = function(event){
	if(this.checked){
		window.albums.forEach(function(item, index, array){
			var year = item.created_time.split("-");
			if($("#album_year_2012").val() == year[0]){
				window.albums_seleccionado_year.push(item);
			}
		});
		window.albums_seleccionado_year.forEach(function(item,index, array){
			$.getJSON('http://graph.facebook.com/'+item.id+'/photos',
				function(response){
					var imagenes = "";
					response.data.forEach(function(item, index, array){
						imagenes += "<div class='miimg'><img src='"+item.picture+"'/></div>";
					});
					$("#contenedor-info-personal").html(
						$("#contenedor-info-personal").html()+imagenes);
			});
		})
	}
}
});